import React from 'react';
import { StyleSheet, View,Text} from 'react-native';

const SettingsScreen = (props) => {
    return (
        <View>
            <Text>Setting screen</Text>
        </View>
    );
}

{/*HUSK AT SKIFTE NAVN*/}
export default SettingsScreen;